PlotBio <- function(field_data,VolEq_DB)
{
  if (!(hasArg(VolEq_DB))) {
    VolEq_DB = readRDS("IndBiom.rdat")
    #data(VolEq_DB, envir=environment()) #if not existing from previous function!!
  }
  
  column_names = colnames(field_data)
  if (!("SpeciesName" %in% colnames(field_data)))
  {
    stop("No Column - SpeciesName Detected in database")
  }
  else if (!("StateName" %in% colnames(field_data)))
  {
    stop("No Column - StateName Detected in database")
  }
  else if (!("Girth" %in% colnames(field_data)))
  {
    stop("No Column - Girth Detected in database")
  }
  else if (!("PlotID" %in% colnames(field_data)))
  {
    stop("No Column - PlotID Detected in database")
  }
  
  print("Input File Ok. Proceeding with Biomass Estimation")
  
  no_samples = nrow(field_data)
  field_data$DBH=rep(NA,no_samples)
  field_data$BA=rep(NA,no_samples)
  field_data$BM=rep(NA,no_samples)
  field_data$Vol = rep(NA,no_samples)
  field_data$WD = rep(NA,no_samples)
  
  pb <- txtProgressBar(min = 0, max = no_samples, style = 3)
  
  for (i in 1:no_samples)
  {
    setTxtProgressBar(pb, i)
    sub_data = field_data[i,]
    sample_spname = as.character(sub_data$SpeciesName)
    sample_statename = as.character(sub_data$StateName)
    sample_girth = as.double(sub_data$Girth) # in cm
    sample_dbh = 0.01*(sample_girth/pi) # conversion to m
    field_data$DBH[i] = sample_dbh
    output = TreeBio(sample_spname,sample_statename,sample_girth,VolEq_DB)
    field_data$BA[i] = as.double(output[1])
    field_data$Vol[i] = as.double(output[2])
    field_data$BM[i] = as.double(output[3])
    field_data$WD[i] = as.double(output[4])
  }
  close(pb)
  
  return(field_data)
}
